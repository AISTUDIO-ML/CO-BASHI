import React from 'react';

function App() {
  return <h1>Welcome to Co-Bashi</h1>;
}

export default App;
