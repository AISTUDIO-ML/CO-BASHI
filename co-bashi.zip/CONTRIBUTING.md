# Contributing to Co-Bashi

We welcome contributions from the community. Please follow these guidelines:

- Fork the repository
- Create a feature branch
- Submit a pull request with a clear description
