# Co-Bashi

Co-Bashi is a SaaS platform for Linux administrators focused on DevOps and shell script automation.

## Features

- FastAPI backend
- React TypeScript frontend
- CI/CD with GitHub Actions
- MIT License
